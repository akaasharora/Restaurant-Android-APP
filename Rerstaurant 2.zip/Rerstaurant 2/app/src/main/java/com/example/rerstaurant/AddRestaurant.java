package com.example.rerstaurant;

import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import java.util.ArrayList;

public class AddRestaurant extends AppCompatActivity {

    DBHandler db;
    ResturantInfo resturantInfo;
    ArrayList al;
    ValidationHelper valid = new ValidationHelper();
    String name, address, phoneNumber, description, tags, rate;
    EditText editName, editAddress, editPhoneNumber, editDescription, editTags;
    RatingBar ratingBar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_restaurant);
        db = new DBHandler(this);

        findViewById(R.id.btnAddSubmit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                al = new ArrayList();

                editName = findViewById(R.id.TxtName);
                editAddress = findViewById(R.id.txtResAddress);
                editPhoneNumber = findViewById(R.id.txtResPhone);
                editDescription = findViewById(R.id.txtResDescription);
                editTags = findViewById(R.id.txtResTags);
                ratingBar = (RatingBar) findViewById(R.id.ratingBar);

                name = editName.getText().toString();
                address = editAddress.getText().toString();
                phoneNumber = editPhoneNumber.getText().toString();
                description = editDescription.getText().toString();
                tags = editTags.getText().toString();
                rate = String.valueOf(ratingBar.getRating());

                if(name.isEmpty()){
                    editName.setError("Name Required!");
                    al.add("E1");
                }
                if(address.isEmpty()){
                    editAddress.setError("Address is required!");
                    al.add("E2");
                }
                if(phoneNumber.isEmpty()){
                    editPhoneNumber.setError("Phone Number required");
                    al.add("E3");
                }else if(valid.formatNumber(phoneNumber) == null){
                    editPhoneNumber.setError("Not a Valid Phone Number!");
                    al.add("E3");
                }
                if(description.isEmpty()){
                    editDescription.setError("Description is required!");
                    al.add("E4");
                }
                if(tags.isEmpty()){
                    editTags.setError("Please! Add one tag.");
                    al.add("E5");
                }

                if(al.size() == 0){
                    resturantInfo = new ResturantInfo(name,address,phoneNumber,description,tags,rate);
                    db.addHandler(resturantInfo);
                    editName.getText().clear();
                    editPhoneNumber.getText().clear();
                    editTags.getText().clear();
                    editDescription.getText().clear();
                    editAddress.getText().clear();
                    ratingBar.setRating(0F);
                    Toast.makeText(getApplicationContext(), "Restaurant successfully added.", Toast.LENGTH_LONG).show();
                }
            }

        });
    }
}
