package com.example.rerstaurant;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewRestaurant extends AppCompatActivity {


    DBHandler db;
    ListView listView;
    EditText editSearchBar;
    ArrayList<String> arrayList;
    ArrayAdapter arrayAdapter;
    String[] data;
    ResturantInfo resturantInfo;
    ValidationHelper validationHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_restaurant);
        validationHelper = new ValidationHelper();
        db = new DBHandler(this);
        final String splitData = db.listViewHandler();

        if (!splitData.isEmpty()) {

            data = splitData.split("\n");

            listView = (ListView) findViewById(R.id.lstRestaurant);

            arrayList = new ArrayList<>();

            for (int i = 0; i < data.length; i++) {
                arrayList.add(data[i]);

            }
            arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1, arrayList);

            listView.setAdapter(arrayAdapter);

            editSearchBar = (EditText) findViewById(R.id.editSearchBar);


            editSearchBar.addTextChangedListener(new TextWatcher() {

                @Override
                public void onTextChanged(CharSequence cs, int arg1, int arg2, int arg3) {

                    arrayList = validationHelper.findResbyTag(splitData,db.tagHandler(), cs);

                    arrayAdapter = new ArrayAdapter(getApplicationContext(), android.R.layout.simple_expandable_list_item_1, arrayList);

                    listView.setAdapter(arrayAdapter);
                }

                @Override
                public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
                    //Toast.makeText(getApplicationContext(),"before text change",Toast.LENGTH_LONG).show();
                }

                @Override
                public void afterTextChanged(Editable arg0) {
                    //Toast.makeText(getApplicationContext(),"after text change",Toast.LENGTH_LONG).show();
                }
            });

            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    String data = arrayList.get(position);
                    String[] splitData = data.split(", ");
                    Log.d("DATA", splitData[0]);
                    Log.d("DATA2", splitData[1]);
                    resturantInfo = db.findHandler(splitData[0]);
                    if (resturantInfo != null) {
                        Log.d("First Name from DB", resturantInfo.getRName());
                        Log.d("Last Name from DB", resturantInfo.getRAddress());
                        Intent intent = new Intent(view.getContext(), DetailView.class);
                        intent.putExtra("Name", resturantInfo.getRName());
                        intent.putExtra("Address", resturantInfo.getRAddress());
                        intent.putExtra("PhoneNumber", resturantInfo.getRPhoneNumber());
                        intent.putExtra("Description", resturantInfo.getRDescription());
                        intent.putExtra("Tags", resturantInfo.getRTags());
                        intent.putExtra("Rating", resturantInfo.getRating());
                        startActivity(intent);
                        finish();
                    } else {
                        Log.d("DB Error:", "The data was not fetched from the database.");
                    }
                }
            });

        }

    }
}
