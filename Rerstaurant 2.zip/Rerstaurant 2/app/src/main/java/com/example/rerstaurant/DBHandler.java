package com.example.rerstaurant;

import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;
import android.database.Cursor;
import android.util.Log;

public class DBHandler extends SQLiteOpenHelper {


    //information of database
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "restaurant.db";
    private static final String TABLE_NAME = "Restaurant";
    private static final String COLUMN_ID = "RestaurantID";
    private static final String COLUMN_NAME = "Name";
    private static final String COLUMN_ADDRESS = "Address";
    private static final String COLUMN_PHNUMBER = "PhoneNumber";
    private static final String COLUMN_DESCRIPTION = "Description";
    private static final String COLUMN_TAGS = "Tags";
    private static final String COLUMN_RATING = "Rating";

    //initialize the database
    public DBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        try {
            String CREATE_TABLE = "CREATE TABLE " + TABLE_NAME + "(" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                    + COLUMN_NAME + " TEXT,"
                    + COLUMN_ADDRESS + " TEXT,"
                    + COLUMN_PHNUMBER + " TEXT,"
                    + COLUMN_DESCRIPTION + " TEXT,"
                    + COLUMN_TAGS + " TEXT,"
                    + COLUMN_RATING + " TEXT"
                    + " );";
            db.execSQL(CREATE_TABLE);
        }catch (Exception e){
            Log.d("DB Error", e.getMessage().toString());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if exist
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        // Create tables again
        onCreate(db);
    }

    public void addHandler(ResturantInfo RInfo){

        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, RInfo.getRName());
        values.put(COLUMN_ADDRESS, RInfo.getRAddress());
        values.put(COLUMN_PHNUMBER, RInfo.getRPhoneNumber());
        values.put(COLUMN_DESCRIPTION, RInfo.getRDescription());
        values.put(COLUMN_TAGS, RInfo.getRTags());
        values.put(COLUMN_RATING, RInfo.getRating());
        db.insert(TABLE_NAME, null, values);
        db.close();

    }

    public String loadHandler(){

        String result = "";
        String query = "SELECT * FROM " + TABLE_NAME;
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            cursor.moveToFirst();
            int result_0 = cursor.getInt(0);
            String result_1 = cursor.getString(1);
            String result_2 = cursor.getString(2);
            String result_3 = cursor.getString(3);
            String result_4 = cursor.getString(4);
            String result_5 = cursor.getString(5);
            String result_6 = cursor.getString(6);

            result += String.valueOf(result_0)+", "+result_1+", "
                    +result_2+", "+result_3+", "+result_4+", "+result_5+", "+result_6 +"\n";
        }

        cursor.close();
        db.close();
        return result;

    }

    public String listViewHandler(){

        String result = "";
        String query = "SELECT "+COLUMN_NAME+" ,  "+COLUMN_ADDRESS+" , "+ COLUMN_TAGS +" FROM " + TABLE_NAME;
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            //cursor.moveToFirst();
            String result_1 = cursor.getString(0);
            String result_2 = cursor.getString(1);
            result += result_1+", "+result_2+ "\n";
        }
        cursor.close();
        db.close();
        Log.d("DB DONE","Yes");
        return result;
    }

    public String tagHandler(){

        String result = "";
        String query = "SELECT "+ COLUMN_TAGS +" FROM " + TABLE_NAME;
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        while(cursor.moveToNext()){
            //cursor.moveToFirst();
            String result_1 = cursor.getString(0);
            result += result_1+", "+ "\n";
        }
        cursor.close();
        db.close();
        Log.d("DB DONE","Yes");
        return result;
    }


    public ResturantInfo findHandler(String Name){


        String query = "SELECT * FROM "+ TABLE_NAME+ "  WHERE " + COLUMN_NAME + " = '"+Name+"' ;";
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        ResturantInfo Restaurant = new ResturantInfo();
        if (cursor.moveToNext()) {
            cursor.moveToFirst();
            Restaurant.setID(cursor.getInt(0));
            Restaurant.setRName(cursor.getString(1));
            Restaurant.setRAddress(cursor.getString(2));
            Restaurant.setRPhoneNumber(cursor.getString(3));
            Restaurant.setRDescription(cursor.getString(4));
            Restaurant.setRTags(cursor.getString(5));
            Restaurant.setRating(cursor.getString(6));
        } else {
            Restaurant = null;
        }
        cursor.close();
        db.close();
        return Restaurant;
    }

    public int duplicateValue(String Name){

        int i = 0;
        String query = "SELECT COUNT ("+ COLUMN_NAME +") FROM "+ TABLE_NAME+ "  WHERE " + COLUMN_NAME + " = '"+Name+"' ;";
        //Get the Data Repository in write mode
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        int count = 0;
        if(null != cursor) {
            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                count = cursor.getInt(0);
            }else{
                count = -1;
            }
            cursor.close();
        }
        db.close();
        return count;
    }

    public boolean updateData(ResturantInfo RInfo, String updateName) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, RInfo.getRName());
        values.put(COLUMN_ADDRESS, RInfo.getRAddress());
        values.put(COLUMN_PHNUMBER, RInfo.getRPhoneNumber());
        values.put(COLUMN_DESCRIPTION, RInfo.getRDescription());
        values.put(COLUMN_TAGS, RInfo.getRTags());
        values.put(COLUMN_RATING, RInfo.getRating());
        db.update(TABLE_NAME, values, COLUMN_NAME +" = ? ",new String[] {updateName});
        return true;
    }

    public Integer deleteContact (String deleteName) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME,
                COLUMN_NAME  + " = ? ",
                new String[] { deleteName });
    }
}


