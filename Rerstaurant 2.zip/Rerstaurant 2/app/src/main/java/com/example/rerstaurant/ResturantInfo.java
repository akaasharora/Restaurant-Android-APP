package com.example.rerstaurant;

public class ResturantInfo {

    String RName, RAddress, RPhoneNumber, RDescription, RTags, Rating;
    Integer ID;

    public ResturantInfo(){

    }

    public ResturantInfo(String RName, String RAddress, String RPhoneNumber, String RDescription, String RTags, String Rating){

        this.RName = RName;
        this.RAddress = RAddress;
        this.RPhoneNumber = RPhoneNumber;
        this.RDescription = RDescription;
        this.RTags = RTags;
        this.Rating = Rating;

    }

    public void setRAddress(String RAddress) {
        this.RAddress = RAddress;
    }

    public String getRAddress() {
        return RAddress;
    }

    public void setRName(String RName) {
        this.RName = RName;
    }

    public String getRName() {
        return RName;
    }

    public void setRPhoneNumber(String RPhoneNumber){ this.RPhoneNumber = RPhoneNumber; }

    public String getRPhoneNumber() {
        return RPhoneNumber;
    }

    public void setRDescription(String RDescription) { this.RDescription = RDescription; }

    public String getRDescription() { return RDescription; }

    public void setRTags(String RTags) { this.RTags = RTags;}

    public String getRTags() { return RTags; }

    public void setID(int ID){ this.ID = ID; }

    public int getID(){ return this.ID; }

    public void setRating(String rating) { Rating = rating; }

    public String getRating() { return Rating; }
}