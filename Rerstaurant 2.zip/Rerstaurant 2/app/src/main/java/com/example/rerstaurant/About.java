package com.example.rerstaurant;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class About extends AppCompatActivity {

    ListView lst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about);

        lst = (ListView)findViewById(R.id.lst_about);

        ArrayList<String> arrayList1 = new ArrayList<>();

        arrayList1.add("Jaydeep Khambholja");
        arrayList1.add("Neel Patel");
        arrayList1.add("Darshan Shah");
        arrayList1.add("Minji Kim");
        arrayList1.add("Akaash Arora");

            ArrayAdapter arrayAdapter1 = new ArrayAdapter(this,android.R.layout.simple_list_item_1,arrayList1);
            lst.setAdapter(arrayAdapter1);

    }
}
