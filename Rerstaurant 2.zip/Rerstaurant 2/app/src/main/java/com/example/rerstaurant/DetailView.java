package com.example.rerstaurant;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Toast;

import java.util.ArrayList;

public class DetailView extends AppCompatActivity {


    DBHandler db;
    ResturantInfo resturantInfo;
    ArrayList al;
    ValidationHelper valid = new ValidationHelper();
    String name, address, phoneNumber, description, tags, rate, Name;
    EditText editName, editAddress, editPhoneNumber, editDescription, editTags;
    Button btnEdit, btnDelete, btnShare, btnMaps;
    RatingBar ratingBar;
    String Address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_view);
        db = new DBHandler(this);




        Intent intent = getIntent();
        Name = intent.getStringExtra("Name");
        Address = intent.getStringExtra("Address");
        String PhoneNumber = intent.getStringExtra("PhoneNumber");
        String Description = intent.getStringExtra("Description");
        String Tags = intent.getStringExtra("Tags");
        String rating = intent.getStringExtra("Rating");





        findID();

        editName.setText(Name);
        editAddress.setText(Address);
        editPhoneNumber.setText(PhoneNumber);
        editDescription.setText(Description);
        editTags.setText(Tags);
        ratingBar.setRating(Float.parseFloat(rating));

        nonClick();

        btnMaps = findViewById(R.id.btnMaps);
        btnMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent ( DetailView.this, MapsActivity.class );
                i.putExtra ( "Resaddress", Address );
                startActivity(i);
            }
        });

        btnEdit = findViewById(R.id.btnEdit);

        findViewById(R.id.btnEdit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                al = new ArrayList();

                findID();

                name = editName.getText().toString();
                address = editAddress.getText().toString();
                phoneNumber = editPhoneNumber.getText().toString();
                description = editDescription.getText().toString();
                tags = editTags.getText().toString();
                rate = String.valueOf(ratingBar.getRating());

                if(btnEdit.getText().toString().equalsIgnoreCase("Done")){
                    if(name.isEmpty()){
                        editName.setError("Name Required!");
                        al.add("E1");
                    }
                    if(address.isEmpty()){
                        editAddress.setError("Address is required!");
                        al.add("E2");
                    }
                    if(phoneNumber.isEmpty()){
                        editPhoneNumber.setError("Phone Number required");
                        al.add("E3");
                    }else if(valid.formatNumber(phoneNumber) == null){
                        editPhoneNumber.setError("Not a Valid Phone Number!");
                        al.add("E3");
                    }
                    if(description.isEmpty()){
                        editDescription.setError("Description is required!");
                        al.add("E4");
                    }
                    if(tags.isEmpty()){
                        editTags.setError("Please! Add one tag.");
                        al.add("E5");
                    }

                    if(al.size() == 0) {
                        resturantInfo = new ResturantInfo(name, address, phoneNumber, description, tags, rate);
                        Log.d("NAME:" , Name);
                        if (db.updateData(resturantInfo, Name)) {
                            Toast.makeText(getApplicationContext(), "Data Modified!", Toast.LENGTH_LONG).show();
                            btnEdit.setText("Edit");
                            nonClick();
                            return;
                        }
                    }

                }

                if(btnEdit.getText().toString().equalsIgnoreCase("Edit")){
                    btnEdit.setText("Done");
                    editName.setEnabled(true);
                    editAddress.setEnabled(true);
                    editPhoneNumber.setEnabled(true);
                    editDescription.setEnabled(true);
                    editTags.setEnabled(true);
                    ratingBar.setEnabled(true);
                }
            }
        });

        findViewById(R.id.btnDelete).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            if(!Name.isEmpty()){
                db.deleteContact(Name);
                editName.getText().clear();
                editPhoneNumber.getText().clear();
                editTags.getText().clear();
                editDescription.getText().clear();
                editAddress.getText().clear();
                ratingBar.setRating(0F);
                Toast.makeText(getApplicationContext(), "Delete Successful !", Toast.LENGTH_LONG).show();
                Intent i = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(i);
                finish();
            }else{
                Toast.makeText(getApplicationContext(), "Name is Empty!", Toast.LENGTH_LONG).show();

            }
            }
        });


        btnShare = (Button) findViewById(R.id.btnShare);
        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = editName.getText().toString();
                Intent intent = new Intent(getApplicationContext(), ShareView.class);
                intent.putExtra("Name",name);
                startActivity(intent);
            }
        });

    }

    public void nonClick(){

        editName.setEnabled(false);
        editAddress.setEnabled(false);
        editPhoneNumber.setEnabled(false);
        editDescription.setEnabled(false);
        editTags.setEnabled(false);
        ratingBar.setEnabled(false);

    }

    public void findID(){
        editName = findViewById(R.id.editTxtName);
        editAddress = findViewById(R.id.editTxtAddress);
        editPhoneNumber = findViewById(R.id.editTxtPhnNum);
        editDescription = findViewById(R.id.editTxtDescr);
        editTags = findViewById(R.id.editTxtTag);
        ratingBar = (RatingBar) findViewById(R.id.editRateBar);
    }

    @Override
    public void onBackPressed(){
        super.onBackPressed();
        Intent i = new Intent(getApplicationContext(), MainActivity.class);
        startActivity(i);
        finish();
    }

}


