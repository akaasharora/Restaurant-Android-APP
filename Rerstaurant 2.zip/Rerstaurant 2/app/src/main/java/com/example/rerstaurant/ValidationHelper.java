package com.example.rerstaurant;

import android.util.Log;

import org.json.JSONObject;

import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationHelper {

    private DBHandler db;
    private static Pattern onlyAlphabets = Pattern.compile("^[a-zA-Z]+$");
    private static Pattern emailNamePtrn = Pattern.compile("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
    private static Pattern phonePtrn = Pattern.compile("^\\(?([0-9]{3})\\)?[-.\\s]?([0-9]{3})[-.\\s]?([0-9]{4})$");

    public ValidationHelper() {

    }

    //checks if the ArrayList is empty or not.
    public boolean isArrayEmpty(ArrayList<String> al) {
        if(al.size() == 0) {
            return true;
        }
        return false;
    }

    //checks if the email matches the regex for email
    public boolean isEmail(String email){
        Matcher mtch = emailNamePtrn.matcher(email);
        if(mtch.matches()){
            return true;
        }
        return false;
    }
    //checks if the string is only alphabets
    public boolean isAlphabetic(String checkStr) {
        Matcher mtch = onlyAlphabets.matcher(checkStr);
        if(mtch.matches()){
            return true;
        }
        return false;
    }

    public String formatNumber(String str){
        Matcher m = phonePtrn.matcher(str);
        if(m.matches()){
            return m.replaceFirst("($1) $2-$3");
        }else{
            return null;
        }
    }

    public ArrayList findResbyTag(String resName, String tag, CharSequence cs){

        String[] Name = resName.split("\n");
        String[] Tag = tag.split("\n");

        ArrayList<String> newList = new ArrayList<String>();
        if(!cs.toString().isEmpty()){
            if (!resName.isEmpty() && !tag.isEmpty()){

                for (int i = 0 ; i < Name.length ; i++){
                    if(Name[i].toLowerCase().contains(cs.toString().toLowerCase())){
                        if(!newList.contains(Name[i])){
                            Log.d("array", Name[i]);
                            newList.add(Name[i]);
                        }
                    }
                }

                for (int i = 0 ; i < Tag.length ; i++){
                    if(Tag[i].toLowerCase().contains(cs.toString().toLowerCase())){
                        if(!newList.contains(Name[i])){
                            Log.d("array", Name[i]);
                            newList.add(Name[i]);
                        }
                    }
                }

            }
        } else{

            for (int i = 0 ; i < Name.length ; i++){
                newList.add(Name[i]);
            }
        }
        return newList;

    }
}
