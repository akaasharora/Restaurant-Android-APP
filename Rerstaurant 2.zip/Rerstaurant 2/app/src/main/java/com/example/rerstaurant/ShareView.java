package com.example.rerstaurant;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
public class ShareView extends AppCompatActivity {

    DBHandler db;
    ResturantInfo resturantInfo;
    Button btnEmailShare, btnFBShare, btnTwitterShare;
    String name, otherInfo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_view);

        btnEmailShare = (Button) findViewById(R.id.btnEmailShare);
        btnFBShare = (Button) findViewById(R.id.btnFBShare);
        btnTwitterShare = (Button) findViewById(R.id.btnTwitterShare);

        db = new DBHandler(this);
        Intent intent = getIntent();
        String Name = intent.getStringExtra("Name");
        resturantInfo = db.findHandler(Name);

        name = resturantInfo.getRName();

        otherInfo = "Name: "+resturantInfo.getRName() +"\n"
                        +"Address: "+resturantInfo.getRAddress() +"\n"
                        +"Phone Number: "+resturantInfo.getRPhoneNumber() +"\n"
                        +"Description: "+resturantInfo.getRDescription() +"\n"
                        +"Rating: "+resturantInfo.getRating() +" / 5.0\n";


        btnEmailShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("other",otherInfo);
                sendEmail(name,otherInfo);
            }
        });


    }

    protected void sendEmail(String name, String otherInfo) {
        Log.d("Send email", "");
        String[] TO = {""};
        String[] CC = {""};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, name);
        emailIntent.putExtra(Intent.EXTRA_TEXT, otherInfo);

        try {
            startActivity(Intent.createChooser(emailIntent, "Share via. Email"));
            Log.d("Finished", "");
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(getApplicationContext(), "There is no email client installed.", Toast.LENGTH_SHORT).show();
        }

    }
}
